import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Confirma_pedidoPage } from './confirma_pedido';

@NgModule({
  declarations: [
    Confirma_pedidoPage,
  ],
  imports: [
    IonicPageModule.forChild(Confirma_pedidoPage),
  ],
})
export class Confirma_pedidoPageModule {}
